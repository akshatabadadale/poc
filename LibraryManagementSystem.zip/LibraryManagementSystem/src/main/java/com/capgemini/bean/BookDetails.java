package com.capgemini.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "book_details")
public class BookDetails {
	
	@Id
	@Column(name = "isbn")
	private int isbn;
	
	@Column(name = "book_title")
	private String bookTitle;
	
	@Column(name = "publishing_year")
	private String publishingYear;
	
	@Column(name = "no_of_copies_actual")
	private int noOfCopiesActual;
	
	@Column(name = "no_of_copies_current")
	private int noOfCopiesCurrent;
	
	
	
	public int getIsbn() {
		return isbn;
	}



	public void setIsbn(int isbn) {
		this.isbn = isbn;
	}



	public String getBookTitle() {
		return bookTitle;
	}



	public void setBookTitle(String bookTitle) {
		this.bookTitle = bookTitle;
	}



	public String getPublishingYear() {
		return publishingYear;
	}



	public void setPublishingYear(String publishingYear) {
		this.publishingYear = publishingYear;
	}



	public int getNoOfCopiesActual() {
		return noOfCopiesActual;
	}



	public void setNoOfCopiesActual(int noOfCopiesActual) {
		this.noOfCopiesActual = noOfCopiesActual;
	}



	public int getNoOfCopiesCurrent() {
		return noOfCopiesCurrent;
	}



	public void setNoOfCopiesCurrent(int noOfCopiesCurrent) {
		this.noOfCopiesCurrent = noOfCopiesCurrent;
	}



	public BorrowerDetails getBorrowedBook() {
		return borrowedBook;
	}



	public void setBorrowedBook(BorrowerDetails borrowedBook) {
		this.borrowedBook = borrowedBook;
	}



	/********RelationShip**********/
	@OneToOne(mappedBy = "book")
	private BorrowerDetails borrowedBook;
}

