package com.capgemini.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bean.EmployeeDetails;
import com.capgemini.repo.EmployeeRepo;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepo employeeRepo;

	public EmployeeDetails addEmployee(EmployeeDetails employee) {

		return employeeRepo.save(employee);

	}
	
	public List<EmployeeDetails> employeeList(){
		 return (List<EmployeeDetails>) employeeRepo.findAll();
	}
	
	public void deleteEmployee(int id) {
		employeeRepo.deleteById(id);
	}

	@Override
	public EmployeeDetails employeeById(int Id) {
		return employeeRepo.findById(Id).get();
		
	}

	@Override
	public EmployeeDetails getByEmployeeIdAndPassword(int id, String pass) {
		return employeeRepo.findByEmployeeIdAndPassword(id, pass);
	}

	



}
