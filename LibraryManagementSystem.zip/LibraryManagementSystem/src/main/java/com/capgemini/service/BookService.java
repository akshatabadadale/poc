package com.capgemini.service;

import java.util.List;

import com.capgemini.bean.BookDetails;

public interface BookService {
	
	public BookDetails addBook(BookDetails body);
	
	public List<BookDetails> bookList();

	public void deleteBook(int id);
}
