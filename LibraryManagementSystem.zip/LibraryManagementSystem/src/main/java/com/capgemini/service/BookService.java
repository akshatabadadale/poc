package com.capgemini.service;

import com.capgemini.bean.BookDetails;

public interface BookService {
	
	public BookDetails addBook(BookDetails body);

}
