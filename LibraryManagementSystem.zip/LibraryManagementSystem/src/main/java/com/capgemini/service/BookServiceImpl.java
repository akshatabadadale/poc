package com.capgemini.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.bean.BookDetails;
import com.capgemini.repo.BookRepo;

@Service
@Transactional
public class BookServiceImpl implements BookService{
	
	@Autowired
	BookRepo bookRepo;

	@Override
	public BookDetails addBook(BookDetails body) {
		
		return bookRepo.save(body);
	}

}
