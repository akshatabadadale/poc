package com.capstore.repo;

import org.springframework.data.repository.CrudRepository;
import com.capstore.bean.WishList;

public interface WishListRepo extends CrudRepository<WishList, Integer> {

}
