package com.capstore.repo;

import org.springframework.data.repository.CrudRepository;

import com.capstore.bean.Address;
import com.capstore.bean.Admin;

public interface AddressRepo extends CrudRepository<Address, Integer> {

}
