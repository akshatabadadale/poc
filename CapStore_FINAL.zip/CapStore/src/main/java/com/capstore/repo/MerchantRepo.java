package com.capstore.repo;

import org.springframework.data.repository.CrudRepository;

import com.capstore.bean.Merchant;

public interface MerchantRepo extends CrudRepository<Merchant, Integer> {

	Merchant findByEmailAndPassword(String email, String password);
}
