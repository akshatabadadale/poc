package com.capstore.service;

/**
 *  Author :- Ajay Amrutkar 173581
 *  version :- 1.0.1
 */
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.RequestParam;

import com.capstore.bean.Address;
import com.capstore.bean.Customer;
import com.capstore.repo.AddressRepo;
import com.capstore.repo.CustomerRepo;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private CustomerRepo repo;

	@Autowired
	private AddressRepo addressRepo;

	@Transactional
	public void saveCustomer(Customer c) {
		repo.save(c);
	}

	@Transactional
	public Iterable<Customer> getAll() {
		return repo.findAll();
	}

	@Transactional
	public Customer getCustomer(int id) {
		return repo.findById(id).get();
	}

	@Transactional
	public String deleteCustomer(int id) {
		repo.deleteById(id);
		return "Delete Successfully";

	}

	/**
	 * @author Ankush Dhodi
	 */
	@Transactional
	public String changePassword(int id, String email, String password) {

		Customer customer = repo.findById(id).get();
		if (customer.getPassword().equals(password)) {
			return "password should not match with previous password";
		} else if (!(customer.getEmail().equals(email))) {
			return "Email is incorrect";
		} else {
			customer.setPassword(password);
			repo.save(customer);
			return "password updated";
		}
	}

	@Transactional
	public Customer getByEmailAndPass(String email, String password) {
		return repo.findByEmailAndPassword(email, password);
	}

	@Transactional
	public void deleteAddress(int id) {
		addressRepo.deleteById(id);
	}

	@Override
	@Transactional
	public Address getAddress(int id) {
		return addressRepo.findById(id).get();
	}
}