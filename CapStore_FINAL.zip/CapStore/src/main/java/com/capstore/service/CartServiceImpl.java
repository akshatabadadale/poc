package com.capstore.service;

/**
 *  Author :- Ajay Amrutkar 173581
 *  version :- 1.0.1
 */
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.capstore.bean.Cart;
import com.capstore.repo.CartProductRepo;
import com.capstore.repo.CartRepo;

@Service
public class CartServiceImpl implements CartService {

	@Autowired
	private CartRepo repo;

	@Autowired
	private CartProductRepo cpRepo;

	@Transactional(propagation = Propagation.REQUIRED)
	public void saveCart(Cart c) {
		repo.save(c);
	}

	@Transactional
	public Iterable<Cart> getAll2() {
		return repo.findAll();
	}

	@Transactional
	public Cart getcartById(int id) {
		return repo.findById(id).get();
	}

	@Transactional
	public void delete(int id) {
		repo.deleteById(id);
	}

	@Transactional
	public void delteCartProduct(int id) {
		cpRepo.deleteById(id);
	}
}
