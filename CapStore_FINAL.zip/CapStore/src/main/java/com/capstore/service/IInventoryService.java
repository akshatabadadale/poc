package com.capstore.service;

import com.capstore.bean.Inventory;

public interface IInventoryService {

	Inventory addInventory(Inventory inv, int productId, int merchantId);

	Inventory updateInventory(Inventory inv, int productId, int merchantId);

	String deleteInventory(int invId);

	Iterable<Inventory> getAllInventries();

	Iterable<Inventory> inventriesOfMerchant(int merchantId);
}
