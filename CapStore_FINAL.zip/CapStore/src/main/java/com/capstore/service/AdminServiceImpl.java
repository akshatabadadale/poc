package com.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capstore.bean.Admin;
import com.capstore.repo.AdminRepo;

@Service
@Transactional
public class AdminServiceImpl implements IAdminService {

	@Autowired
	AdminRepo repo;

	@Override
	public Admin getByEmailAndPass(String email, String password) {
		return repo.findByEmailAndPassword(email, password);
	}

}
