/*
 * Author :- Mayuresh Shinde 173560
 * version:- 1.0.1
 */
package com.capstore.service;

import java.util.List;

import com.capstore.bean.Category;
import com.capstore.bean.Inventory;
import com.capstore.bean.Product;

public interface IProductService {
	Category addCategory(Category category);

	Category updateCategory(Category category);

	String deleteCategory(int catId);

	Product saveProduct(Product product, int catId);

	Product updateProduct(Product product, int catId);

	String deleteProduct(int productId);

	Iterable<Category> getAllCategory();

	Iterable<Product> getAllProduct();

	List<Product> getAllProductOfMerchant(int merchantId);

	Product getProduct(int id);

	List<Product> findByname(String name);

	Iterable<Product> findByProductName(String productName);

	Iterable<Product> findByProductBrand(String productBrand);

	Category getCategory(int id);
}
