package com.capstore.service;

import com.capstore.bean.Address;
import com.capstore.bean.Customer;

/**
 * Author :- Ajay Amrutkar 173581 version :- 1.0.1
 */

public interface CustomerService {

	void saveCustomer(Customer c);

	Iterable<Customer> getAll();

	public String deleteCustomer(int id);

	Customer getCustomer(int id);

	String changePassword(int id, String email, String password);

	Customer getByEmailAndPass(String email, String password);

	void deleteAddress(int id);

	Address getAddress(int id);
}
