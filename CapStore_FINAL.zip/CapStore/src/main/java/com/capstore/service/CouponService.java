/*
 * CouponService Interface
 * Author : Mayur Hiwarkar
 * 
 */
package com.capstore.service;

import com.capstore.bean.Coupon;

public interface CouponService {

	public Coupon couponGenerateAndSend(Coupon c);

}
