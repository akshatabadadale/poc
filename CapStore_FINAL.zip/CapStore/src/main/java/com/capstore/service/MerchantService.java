package com.capstore.service;

import com.capstore.bean.Merchant;

public interface MerchantService {
	void saveMerchant(Merchant merchant);

	Merchant findById(int id);

	public String deleteMerchant(int id);

	Iterable<Merchant> getAll();

	Merchant getByEmailAndPass(String email, String password);
}
