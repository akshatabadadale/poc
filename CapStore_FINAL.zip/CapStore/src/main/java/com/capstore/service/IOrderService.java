package com.capstore.service;

import com.capstore.bean.Order;

public interface IOrderService {

	Order saveOrder(Order order);

	Order getOrder(int id);

	void updateInventory(int quantity, int merchId, int productId);
}
