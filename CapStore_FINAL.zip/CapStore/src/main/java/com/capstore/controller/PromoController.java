/**
 * @Author Laxmi Bugade
 * @version: 1.0.0
 * It is controller of promo
 */

package com.capstore.controller;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.bean.Promo;
import com.capstore.service.PromoService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/promo")
public class PromoController {
	@Autowired
	private PromoService service;

	@GetMapping(path = "/{id}")
	public ResponseEntity<?> get(@PathVariable("id") int id) {
		try {
			Promo p = service.get(id);
			return new ResponseEntity<Promo>(p, HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity<String>("Sorry. No Promo Found", HttpStatus.NOT_FOUND);
		}
	}

	// Add new Promo to DB
	@PostMapping(path = "/add", consumes = "application/json", produces = "application/json")
	public String savePromo(@RequestBody Promo promo) {
		service.savePromo(promo);
		return "Promo Saved Successfully";
	}
}
