package com.capstore.controller;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.capstore.bean.Customer;
import com.capstore.bean.Product;
import com.capstore.bean.ProductWishList;
import com.capstore.bean.WishList;
import com.capstore.service.CustomerService;
import com.capstore.service.IProductService;
import com.capstore.service.IWishListService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/wishlist")
public class WishListController {

	@Autowired
	private CustomerService custService;

	@Autowired
	private IProductService prodService;

	@Autowired
	private IWishListService wishService;

	@PostMapping(path = "/addWish/{custId}/{productId}", consumes = "application/json", produces = "application/json")
	public ResponseEntity<String> addToWishList(@PathVariable("custId") int custId,
			@PathVariable("productId") int productId, @RequestBody WishList wishList) {
		Customer cust = custService.getCustomer(custId);
		Product prod = prodService.getProduct(productId);
		wishList.setCustomer(cust);
		ProductWishList prodWish = new ProductWishList();
		prodWish.setWishList(wishList);
		prodWish.setProductFromWishList(prod);
		wishList.addProduct(prodWish);
		wishService.saveWishList(wishList);
		return new ResponseEntity<String>("product added to WishList", HttpStatus.OK);
	}

	@GetMapping(path = "/get/{custId}")
	public ResponseEntity<?> wishListProducts(@PathVariable("custId") int custId) {
		Customer cust = custService.getCustomer(custId);
		WishList wishList = cust.getWishList();
		List<ProductWishList> list = wishList.getProductsWishList();
		List<Product> products = new ArrayList<Product>();
		for (ProductWishList prodWish : list) {
			products.add(prodWish.getProductFromWishList());
		}
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}

}
