package com.capstore.controller;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.capstore.bean.Address;
import com.capstore.bean.Cart;
import com.capstore.bean.CartProduct;
import com.capstore.bean.Customer;
import com.capstore.bean.Order;
import com.capstore.bean.OrderProduct;
import com.capstore.bean.Product;
import com.capstore.service.CartService;
import com.capstore.service.CustomerService;
import com.capstore.service.IOrderService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/order")
public class OrderController {

	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");

	@Autowired
	private CartService cartService;

	@Autowired
	private CustomerService custService;

	@Autowired
	private IOrderService orderService;

	@PostMapping(path = "/checkout/{cartId}/{addId}/{merchantId}/{totalAmout}")
	public ResponseEntity<Order> checkout(@PathVariable("cartId") int cartId, @PathVariable("addId") int addId,
			@PathVariable("merchantId") int merchId, @PathVariable("totalAmout") double amount) {
		Cart cart = cartService.getcartById(cartId);
		List<CartProduct> cartProd = cart.getCartProducts();
		Order order = new Order();
		LocalDateTime now = LocalDateTime.now();
		order.setDate(dtf.format(now));
		order.setCustomerFromOrder(cart.getCustomerFromCart());
		Address address = custService.getAddress(addId);
		order.setAddressFromOrder(address);
		order.setAmount(amount);
		order = orderService.saveOrder(order);
		for (CartProduct cartProduct : cartProd) {
			OrderProduct orderProduct = new OrderProduct();
			orderProduct.setOrder(order);
			Product product = cartProduct.getProduct();
			orderProduct.setProductFromOrderProduct(product);
			order.addOrderProduct(orderProduct);
			orderService.updateInventory(cartProduct.getQuantity(), merchId, product.getId());
		}

		orderService.saveOrder(order);
		cartService.delete(cartId);
		return new ResponseEntity<Order>(order, HttpStatus.OK);
	}

	@GetMapping(path = "/{custId}")
	public ResponseEntity<List<Order>> getOrders(@PathVariable("custId") int custId) {
		Customer customer = custService.getCustomer(custId);
		List<Order> orders = customer.getOrders();
		return new ResponseEntity<List<Order>>(orders, HttpStatus.OK);
	}

	@GetMapping("/product/{custId}")
	public ResponseEntity<List<Product>> getProducts(@PathVariable("custId") int custId) {
		Customer customer = custService.getCustomer(custId);
		List<Order> orders = customer.getOrders();
		List<Product> products = new ArrayList<Product>();
		for (Order order : orders) {
			List<OrderProduct> orderProducts = order.getOrderProducts();
			for (OrderProduct orderProduct : orderProducts) {
				products.add(orderProduct.getProductFromOrderProduct());
			}
		}
		return new ResponseEntity<List<Product>>(products, HttpStatus.OK);
	}
}
