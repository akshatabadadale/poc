/*
 * Author :- Mayuresh Shinde 173560
 * version:- 1.0.1
 */
package com.capstore.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.stream.StreamSupport;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.capstore.bean.Category;
import com.capstore.bean.Inventory;
import com.capstore.bean.Merchant;
import com.capstore.bean.MostView;
import com.capstore.bean.Product;
import com.capstore.service.IProductService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/product")
public class ProductController {

	@Autowired
	IProductService service;

	/**
	 * @author Mayuresh Shinde 
	 * create a category
	 * @return ResponseEntity<Category>
	 */
	@PostMapping(path = "/category", consumes = "application/json", produces = "application/json")
	public ResponseEntity<Category> addCategory(@RequestBody Category category) {
		return new ResponseEntity<Category>(service.addCategory(category), HttpStatus.OK);
	}

	/**
	 * @author Mayuresh Shinde 
	 * update a category
	 * @return ResponseEntity<Category>
	 */
	@PutMapping(path = "/category", consumes = "application/json")
	public ResponseEntity<Category> updateCategory(@RequestBody Category category) {
		return new ResponseEntity<Category>(service.updateCategory(category), HttpStatus.OK);
	}

	@GetMapping(path = "/getcat/{catId}")
	public ResponseEntity<Category> getCategory(@PathVariable("catId") int catId) {
		return new ResponseEntity<Category>(service.getCategory(catId), HttpStatus.OK);
	}

	/**
	 * @author Akash Ganji 
	 * fetch product
	 */
	@GetMapping(path = "/get/{prodId}")
	public ResponseEntity<Product> getProduct(@PathVariable("prodId") int prodId) {
		Product product = service.getProduct(prodId);
		MostView mostView = product.getMostView();
		if (mostView == null) {
			mostView = new MostView();
			mostView.setProductFromMostView(product);
			mostView.setViewCount(1);
			product.setMostView(mostView);
		} else
			mostView.setViewCount(mostView.getViewCount() + 1);
		Category cat = product.getCategory();
		service.saveProduct(product, cat.getId());
		return new ResponseEntity<Product>(product, HttpStatus.OK);
	}

	/**
	 * @author Mayuresh Shinde 
	 * delete a category
	 * @return ResponseEntity<String>
	 */
	@DeleteMapping(path = "/category/{catId}")
	public ResponseEntity<String> deleteCategory(@PathVariable int catId) {
		try {
			return new ResponseEntity<String>(service.deleteCategory(catId), HttpStatus.OK);
		} catch (EmptyResultDataAccessException e) {
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	/**
	 * @author Mayuresh Shinde 
	 * create a product
	 * @return
	 */
	@PostMapping(path = "/{catId}", consumes = "application/json", produces = "application/json")
	public ResponseEntity<Product> addproduct(@RequestBody Product product, @PathVariable int catId) {
		return new ResponseEntity<Product>(service.saveProduct(product, catId), HttpStatus.OK);
	}

	/**
	 * @author Mayuresh Shinde 
	 * update a product
	 * @return ResponseEntity<Product>
	 */
	@PutMapping(path = "/{catId}", consumes = "application/json")
	public ResponseEntity<Product> updateProduct(@RequestBody Product product, @PathVariable int catId) {
		return new ResponseEntity<Product>(service.updateProduct(product, catId), HttpStatus.OK);
	}

	/**
	 * @author Mayuresh Shinde 
	 * delete a product
	 * @return ResponseEntity<String>
	 */
	@DeleteMapping(path = "/{productId}")
	public ResponseEntity<String> deleteProduct(@PathVariable("productId") int productId) {
		try {
			return new ResponseEntity<String>(service.deleteProduct(productId), HttpStatus.OK);
		} catch (EmptyResultDataAccessException e) {
			return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	/**
	 * @author Mayuresh Shinde
	 * @return all categories
	 */
	@GetMapping(path = "/categories", produces = "application/json")
	public ResponseEntity<Iterable<Category>> getAllCategory() {
		return new ResponseEntity<Iterable<Category>>(service.getAllCategory(), HttpStatus.OK);
	}

	/**
	 * @author Mayuresh Shinde
	 * @return all products(for admin)
	 */
	@GetMapping(path = "/all", produces = "application/json")
	public ResponseEntity<Iterable<Product>> getAllProduct() {
		return new ResponseEntity<Iterable<Product>>(service.getAllProduct(), HttpStatus.OK);
	}

	/**
	 * @author Mayuresh Shinde
	 * @return all products of specific merchant
	 */
	@GetMapping(path = "/merchant/{merchantId}", produces = "application/json")
	public ResponseEntity<List<Product>> getAllProductOfMerchant(@PathVariable("merchantId") int merchantId) {
		return new ResponseEntity<List<Product>>(service.getAllProductOfMerchant(merchantId), HttpStatus.OK);
	}

	@GetMapping(path = "/getmerchant/{prodId}")
	public ResponseEntity<List<Merchant>> getMerchants(@PathVariable("prodId") int prodId) {
		Product product = service.getProduct(prodId);
		List<Inventory> inventries = product.getInventory();
		List<Merchant> merchants = new ArrayList<>();
		for (Inventory inventory : inventries) {
			merchants.add(inventory.getMerchant());
		}
		return new ResponseEntity<List<Merchant>>(merchants, HttpStatus.OK);
	}

	/*
	 * Author :- Pradnya Gaikwad 173579 version:- 1.0.1
	 */

	@GetMapping(path = "/getbyname/{name}", produces = "application/json")
	public List<Product> getSimilarProductsByCategory(@PathVariable("name") String categoryName) {
		return service.findByname(categoryName);
	}

	/**
	 * @author Durvesh
	 */
	@GetMapping(path = "/getproduct", produces = "application/json")
	ResponseEntity<?> findProduct(@RequestParam("queryString") String queryString) {

		Iterable<Product> productList;
		long count;

		queryString = queryString.toLowerCase();
		if (queryString == null) {
			return new ResponseEntity<String>("Please enter a search keyword", HttpStatus.BAD_REQUEST);
		} else {
			try {
				productList = service.findByProductName(queryString);
				count = StreamSupport.stream(productList.spliterator(), false).count();
				if (count != 0) {
					return new ResponseEntity<Iterable<Product>>(productList, HttpStatus.OK);
				}
				productList = service.findByProductBrand(queryString);
				count = StreamSupport.stream(productList.spliterator(), false).count();
				if (count != 0) {
					return new ResponseEntity<Iterable<Product>>(productList, HttpStatus.OK);
				}

			} catch (NoSuchElementException e) {
				return new ResponseEntity<String>(e.getMessage(), HttpStatus.NOT_FOUND);
			} finally {
				count = 0;
			}
		}
		return null;

	}
}
