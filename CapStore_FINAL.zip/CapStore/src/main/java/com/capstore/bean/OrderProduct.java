package com.capstore.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;

@Entity
@Table(name = "order_product")
@SequenceGenerator(name = "orderproseq", sequenceName = "orderpro_seq", initialValue = 101)
public class OrderProduct {

	@Id
	@Column(name = "op_id", length = 10)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "orderproseq")
	private int id;

	/************** Relationships ******************/
	
	@JsonBackReference(value = "order-product")
	@ManyToOne
	@JoinColumn(name = "order_id")
	private Order order;

	@JsonBackReference(value = "product-order")
	@ManyToOne
	@JoinColumn(name = "product_id")
	private Product productFromOrderProduct;

	/************ Getters and setters ***************/

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public Product getProductFromOrderProduct() {
		return productFromOrderProduct;
	}

	public void setProductFromOrderProduct(Product productFromOrderProduct) {
		this.productFromOrderProduct = productFromOrderProduct;
	}

}
