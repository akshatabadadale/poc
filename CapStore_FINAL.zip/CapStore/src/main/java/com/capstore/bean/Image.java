/*
 * Author :- Mayuresh Shinde 173560
 * version:- 1.0.3
 */
package com.capstore.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "image")
@SequenceGenerator(name = "imgseq", sequenceName = "image_seq", initialValue = 101)
public class Image {
	@Id
	@Column(name = "image_id", length = 10)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "imgseq")
	private int id;

	@Column(name = "image_path")
	private String path;

	/************** Relationships ******************/
	
	@JsonBackReference(value = "product-image")
	@ManyToOne
	@JoinColumn(name = "product_id")
	private Product productFromImage;

	/************ Getters and setters ***************/
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	@JsonIgnore
	public Product getProductFromImage() {
		return productFromImage;
	}

	public void setProductFromImage(Product productFromImage) {
		this.productFromImage = productFromImage;
	}

	@Override
	public String toString() {
		return "Image [id=" + id + ", path=" + path + ", productFromImage=" + productFromImage + "]";
	}

}
