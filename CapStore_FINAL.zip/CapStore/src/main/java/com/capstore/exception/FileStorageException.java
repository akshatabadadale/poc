package com.capstore.exception;
/**
 * This is the Exception class for file storage 
 * @author yash naik
 *
 */
public class FileStorageException extends RuntimeException {
    public FileStorageException(String message) {
        super(message);
    }

    public FileStorageException(String message, Throwable cause) {
        super(message, cause);
    }
}
