import { Component, OnInit } from '@angular/core';
import { ServiceService } from '../service.service';
import { MatTableDataSource } from '@angular/material';
import { dvd } from '../model/dvd';

@Component({
  selector: 'app-dvd',
  templateUrl: './dvd.component.html',
  styleUrls: ['./dvd.component.css']
})
export class DvdComponent implements OnInit {

  displayedColumns = ['dvdNo', 'dvdTitle', 'publishingYear', 'noOfCopiesActual', 'noOfCopiesCurrent'];
  dataSource;
  dvdArr: dvd[] = [];
  dvd1: dvd;
  dvd2: dvd;
  dvd3: dvd;
  resultTrue = false;

  constructor(private serviceService: ServiceService) { }

  ngOnInit() {
    this.getAll();


    this.dvd1 = new dvd();
    this.dvd2 = new dvd();
    this.dvd3 = new dvd();

    this.dvd1.dvdNo = 51;
    this.dvd1.dvdTitle = 'JAVA DVD';
    this.dvd1.publishingYear = '2014';
    this.dvd1.noOfCopiesActual = 5;
    this.dvd1.noOfCopiesCurrent = 2;

    this.dvd2.dvdNo = 52;
    this.dvd2.dvdTitle = 'Oracle DVD';
    this.dvd2.publishingYear = '2016';
    this.dvd2.noOfCopiesActual = 7;
    this.dvd2.noOfCopiesCurrent = 5;

    this.dvd3.dvdNo = 53;
    this.dvd3.dvdTitle = 'Angular 7 DVD';
    this.dvd3.publishingYear = '2018';
    this.dvd3.noOfCopiesActual = 12;
    this.dvd3.noOfCopiesCurrent = 10;

    this.dvdArr.push(this.dvd1);
    this.dvdArr.push(this.dvd2);
    this.dvdArr.push(this.dvd3);
  }
  getAll() {
    console.log(this.dvdArr);
    this.serviceService.dvdDetails()
    this.dataSource = new MatTableDataSource(this.dvdArr);

  }

}
