import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { BookComponent } from './book/book.component';
import { RegisterComponent } from './register/register.component';
import { LoginComponent } from './login/login.component';
import { MagazineComponent } from './magazine/magazine.component';
import { DvdComponent } from './dvd/dvd.component';
import { HomeComponent } from './home/home.component';
import { AdminComponent } from './admin/admin.component';
import { EditBookComponent } from './edit-book/edit-book.component';
import { StudentComponent } from './student/student.component';


const routes: Routes = [
  { path: '', redirectTo: '/home', pathMatch: 'full' },
  {path:'home',component:HomeComponent},
  { path: 'book', component: BookComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'login', component: LoginComponent },
  { path: 'magazine', component: MagazineComponent },
  { path: 'dvd', component: DvdComponent },
  { path: 'admin', component: AdminComponent },
  { path: 'edit-book', component: EditBookComponent },
  { path: 'student', component: StudentComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
