export class Login {
  public employeeId: number;
  public password: String;
  public conversionEncryptOutput: string;
}
