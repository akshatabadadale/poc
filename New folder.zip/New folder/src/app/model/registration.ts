export class Registration {
  public employeeId: number;
  public firstName: String;
  public lastName: String;
  public gender: String;
  public mbNumber: String;
  public password: String;
  public repeatpassword: String;
}
