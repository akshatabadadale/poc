// tslint:disable-next-line: class-name
export class dvd{
  dvdNo: number;
  dvdTitle: String;
  publishingYear: String;
  noOfCopiesActual: number;
  noOfCopiesCurrent: number;


}
