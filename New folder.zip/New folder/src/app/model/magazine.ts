// tslint:disable-next-line: class-name
export class magazine {
  magNo: number;
  magazineTitle: String;
  noOfCopiesActual: number;
  noOfCopiesCurrent: number;


}
