export class book{
  isbn: number;
  bookTitle: String;
  publishingYear: String;
  noOfCopiesActual: number;
  noOfCopiesCurrent: number;


}
