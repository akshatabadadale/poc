import { Injectable } from "@angular/core";
import { Registration } from "./model/registration";
import { Login } from "./model/login";
import { Router } from "@angular/router";
import { HttpClient } from "@angular/common/http";
import { book } from "./model/book";
import { magazine } from "./model/magazine";
import { dvd } from "./model/dvd";
import { editbook } from "./model/editbook";
import { Observable } from "rxjs";

@Injectable({
  providedIn: "root"
})
export class ServiceService {
  baseHref = "http://localhost:8888";
  constructor(private http: HttpClient, private routes: Router) {}
  postOne(login: Login): Observable<Object> {
    let id = login.employeeId;
    let pass = login.password;
    return this.http.get(this.baseHref + `/employeeById/${id}/${pass}`);
  }
  registerDetails(register: Registration) {
    // var body={
    //   employeeId: register.employeeId,
    //   firstName:register.firstname,
    //   lastName:register.lastname,
    //   password:register.password,
    //   mbNumber:"8286703935"
    // }
    return this.http.post<Login>(this.baseHref + "/addemployee", register);
  }

  bookDetails() {
    return this.http.get<book[]>(this.baseHref + "/allbooks");
  }
  dvdDetails() {
    return this.http.get<dvd[]>(this.baseHref + "/alldvds");
  }
  magazineDetails() {
    return this.http.get<magazine[]>(this.baseHref + "/allmagazine");
  }
  storeBookDetails(obj: editbook): any {
    // this.recievedBook = obj;
  }
  getBookDetails() {
    // return this.receivedObj;
  }
}
