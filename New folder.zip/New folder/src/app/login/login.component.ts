import { Registration } from './../model/registration';
import { ServiceService } from '../service.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, Validators } from '@angular/forms';
import * as sha1 from 'sha1/sha1';
import { Login } from '../model/login';




@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  inputEmail: string;
  conversionEncryptOutput: string;
  login: Login;
  hide = true;
  // employeeId = new FormControl('', [Validators.required, Validators.employeeId]);
  passwordControl = new FormControl('', [Validators.required]);

  constructor(private service: ServiceService, private router: Router) {
    this.login = new Login();
  }
  ngOnInit() { }

  // set validaion error message for email
  // getErrorMessage() {
  //   return this.employeeId.hasError('required')
  //     ? 'employeeId is required'
  //     : this.employeeId.hasError('employeeId')
  //       ? 'Not a valid employeeId'
  //       : '';
  // }
  loginn() {
    console.log("login");
  }
  encryptPassword() {
    // using crypto js

    /*this.conversionEncryptOutput = CryptoJS.AES.encrypt(
      this.logon.password.trim(),
      this.logon.email.trim()
    ).toString();*/

    // using sha1
    this.conversionEncryptOutput = sha1(this.login.password);
    this.login.password = this.conversionEncryptOutput;
  }
  addOneUser() {
    this.service.postOne(this.login).subscribe(
      result => {
        console.log(result);
        localStorage.setItem('EMPLOYEE', JSON.stringify(result as Registration));

        // console.log(JSON.parse(localStorage.getItem('EMPLOYEE')));
        // console.log("Added Successfully");
        this.router.navigate(["/"]);
      },
      error => {
        console.log(error);
      }
    );
  }

  // sendLoginCredentials() {
  //   this.encryptPassword();
  //   this.service.login(this.logon).subscribe(
  //     result => {
  //       console.log(result);
  //       localStorage.setItem("user", JSON.stringify(result));
  //       this.service.loggedCustomer = result;
  //       this.service.isLogged = true;
  //       this.router.navigate(["/"]);
  //     },
  //     error => {
  //       this.logon.password = ""
  //       this.snackBar.open("Invalid Credentials", "", {
  //         duration: 4000,
  //       });
  //     }
  //   );
  // }
  // navigateToForgotPwd() {
  //   this.router.navigate(['/forgotpassword']);
  // }
}
