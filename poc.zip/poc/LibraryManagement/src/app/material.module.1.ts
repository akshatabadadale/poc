import { NgModule } from '@angular/core';
// import {  MatButtonModule } from '@angular/material';


import {
  MatCardModule, MatDialogModule, MatInputModule, MatTableModule,
  MatToolbarModule, MatMenuModule,MatIconModule, MatProgressSpinnerModule,
  MatNativeDateModule, MatDatepickerModule, MatCheckboxModule, MatFormFieldModule,
   MatListModule, MatRadioModule, MatButtonModule, MatGridListModule, MatOptionModule, MatSelectModule} from '@angular/material';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

@NgModule({
  imports: [
    MatButtonModule,
    CommonModule,
  MatToolbarModule,
  MatCardModule,
  MatInputModule,
  MatDialogModule,
  MatTableModule,
  MatMenuModule,
  MatIconModule,
  MatProgressSpinnerModule,
  MatNativeDateModule,
  MatDatepickerModule,
  MatIconModule,
  MatCheckboxModule,
  MatToolbarModule,
  FormsModule,
  MatCardModule,
  MatFormFieldModule,
  MatInputModule,
  MatListModule,
  MatRadioModule,
  MatGridListModule,
  MatTableModule,
  MatOptionModule,
  MatFormFieldModule,
  MatSelectModule



  ],

  exports:[

  CommonModule,
   MatToolbarModule,
   MatButtonModule,
   MatCardModule,
   MatInputModule,
   MatDialogModule,
   MatTableModule,
   MatMenuModule,
   MatIconModule,
   MatProgressSpinnerModule,
   MatNativeDateModule,
   MatDatepickerModule,
   MatIconModule,
   MatCheckboxModule,
   MatToolbarModule,
   FormsModule,
   MatCardModule,
   MatFormFieldModule,
   MatInputModule,
   MatListModule,
   MatRadioModule,
   MatGridListModule,
   MatTableModule,
   MatOptionModule,
   MatFormFieldModule,
   MatSelectModule


  ]
})
export class LmsMaterialModule { }
