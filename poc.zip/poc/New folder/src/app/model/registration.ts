export class Registration {
  [x: string]: any;
  employeeId: number;
    firstname: String;
    lastname: String;
    gender: String;
    contact: number;
    password: String;
    repeatpassword: String;
  }
