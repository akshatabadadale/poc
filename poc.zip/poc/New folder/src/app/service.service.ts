import { Injectable } from '@angular/core';
import { Registration } from './model/registration';
import { Login } from './model/login';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { book } from './model/book';
import { magazine } from './model/magazine';
import { dvd } from './model/dvd';
import { editbook } from './model/editbook';

@Injectable({
  providedIn: 'root'
})
export class ServiceService {
  login = new Login();
  receivedObj: Registration;
  recievedBook: editbook;
  bookArr: book[];
  dvdArr: dvd[];
  magArr: magazine[];
  baseHref = 'http://localhost:8888';
  constructor(private http: HttpClient, private routes: Router) {
  }
  postOne(login: Login) {
    return this.http.post<Login>(this.baseHref + '/login', login);
  }
  registerDetails(register: Registration) {
    return this.http.post<Login>(this.baseHref + '/addemployee', register);
  }
  storeDetails(obj: Registration): any {
    this.receivedObj = obj;
  }
  bookDetails() {
    return this.http.get<book[]>(this.baseHref + '/allbooks');
  }
  dvdDetails() {
    return this.http.get<dvd[]>(this.baseHref + '/alldvds');
  }
  magazineDetails() {
    return this.http.get<magazine[]>(this.baseHref + '/allmagazine');
  }
  storeBookDetails(obj: editbook): any {
    this.recievedBook = obj;
  }
  getBookDetails() {
    return this.receivedObj;
  }


}
