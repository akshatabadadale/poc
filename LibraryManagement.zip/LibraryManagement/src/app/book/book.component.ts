import { Component, OnInit, ViewChild } from '@angular/core';
import { ServiceService } from '../service.service';
import { book } from '../model/book';
import { MatTableDataSource } from '@angular/material';
import { Registration } from '../model/registration';
import { editbook } from '../model/editbook';
import { Router } from '@angular/router';



@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {
  [x: string]: any;
  // displayedColumns =['isbn', 'bookTitle', 'publishingYear', 'noOfCopiesActual', 'noOfCopiesCurrent'];
  // dataSource;
  registeredDetails: Registration;
 bookToEdit: editbook;
 isEditing: boolean ;
  book: book;
  bookArr: book[] = [];


  constructor(private serviceService: ServiceService, private router:Router) {
    this.book = new book();
    this.registeredDetails = new Registration();
    }

  ngOnInit() {
    this.getAll();
    this.registeredDetails = this.serviceService.getBookDetails();

    // this.book1 = new book();
    // this.book2 = new book();
    // this.book3= new book();

    // this.book1.isbn = 1234;
    // this.book1.bookTitle = 'JAVA Progamming';
    // this.book1.publishingYear = '2017';
    // this.book1.noOfCopiesActual = 5;
    // this.book1.noOfCopiesCurrent = 3;

    // this.book2.isbn = 1235;
    // this.book2.bookTitle = 'Oracle Database';
    // this.book2.publishingYear = '2018';
    // this.book2.noOfCopiesActual = 7;
    // this.book2.noOfCopiesCurrent = 5;

    // this.book3.isbn = 1236;
    // this.book3.bookTitle = 'Angular 7';
    // this.book3.publishingYear = '2019';
    // this.book3.noOfCopiesActual = 12;
    // this.book3.noOfCopiesCurrent = 10;

    // this.bookArr.push(this.book1);
    // this.bookArr.push(this.book2);
    // this.bookArr.push(this.book3);
}
getAll() {
  console.log(this.bookArr);
  this.serviceService.bookDetails()
  this.dataSource = new MatTableDataSource(this.bookArr);

}
navigateToEdit(){

  this.router.navigate(['/edit-book']);

}

}
