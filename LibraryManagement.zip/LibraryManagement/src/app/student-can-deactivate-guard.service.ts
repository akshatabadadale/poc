import { CanDeactivate } from '@angular/router/src/utils/preactivation';
import { RegisterComponent } from './register/register.component';
import { Injectable } from '@angular/core';

@Injectable()
export class StudentCanDeactivcateGaurd implements CanDeactivate {
  component: RegisterComponent;
  route: import('@angular/router').ActivatedRouteSnapshot;
  canDeactivate(): boolean{
    if (component.RegisterComponent.dirty) {
      return confirm('Are you sure you want to discard the changes?');
    }
    return true;
  }
}



