import { Component, OnInit, Input, ViewChild } from '@angular/core';
import { FormControl, Validators, Form } from '@angular/forms';
import { Registration } from '../model/registration';
import { ServiceService } from '../service.service';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  [x: string]: any;
@ViewChild('my-form') public registerForm: Form;
  registration: Registration;

@Input() isEditing: boolean;

  constructor(private service: ServiceService) {
    this.registration = new Registration();
   }
  email = new FormControl('', [Validators.required, Validators.email]);
  ngOnInit() {
  }
  getErrorMessage() {
    return this.email.hasError('required')
      ? 'You must enter a value'
      : this.email.hasError('email')
      ? 'Not a valid email'
      : '';
  }
validateboth() {
    if (this.registration.password === this.registration.repeatpassword) {
      alert('Password match');

    } else {
      alert('Password do not match');
      this.registration.password = '';
      this.registration.repeatpassword ='';
    }
  }
  register() {
      this.service.registerDetails(this.registration).subscribe(
        result => {
          console.log(result);
          console.log("Registered Successfully");
        },
        error => {
          console.log(error);
        }
      );
  }
}
