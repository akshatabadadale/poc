export class Registration {
  [x: string]: any;
    firstname: String;
    lastname: String;
    address: String;
    email: String;
    password: String;
    repeatpassword: String;
    gender: String;
    dateofbirth: String;
  }
