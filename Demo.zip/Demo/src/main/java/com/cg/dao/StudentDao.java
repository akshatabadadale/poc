package com.cg.dao;

import java.util.List;

import com.cg.bean.StudentDetails;

public interface StudentDao {
	
	 public List<StudentDetails>getAllStudents();

}
