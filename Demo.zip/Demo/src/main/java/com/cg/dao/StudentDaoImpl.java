package com.cg.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.bean.StudentDetails;
@Repository
public class StudentDaoImpl implements StudentDao {


	public List<StudentDetails>getAllStudents() {
		
		List<StudentDetails> students = new ArrayList<StudentDetails>();
		
		
		StudentDetails s1 = new StudentDetails();
		s1.setRollNo(1);
		s1.setFirstName("Akshata");
		s1.setMiddleName("Annaray");
		s1.setLastName("Badadale");
		s1.setAge("23");
		s1.setContactNumber("7777024330");
		s1.setSchoolName("D.A.V.Public School");
		s1.setAddress("Airoli");
		students.add(s1);
		
		
		StudentDetails s2 = new StudentDetails();
		s2.setRollNo(2);
		s2.setFirstName("Aditya");
		s2.setLastName("Sinha");
		s2.setAge("23");
		s2.setContactNumber("7777024331");
		s2.setSchoolName("D.A.V.Public School");
		s2.setAddress("digha");
		students.add(s2);
		
		return students;
		
}
}
