package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.bean.StudentDetails;
import com.cg.dao.StudentDao;
@Service
public class StudentServiceImpl implements StudentService {

	@Autowired
	StudentDao studentDao;
	
	public List<StudentDetails> getAllStudents() {
		return studentDao.getAllStudents();
	}

}
