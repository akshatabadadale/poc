package com.cg.service;

import java.util.List;

import com.cg.bean.StudentDetails;

public interface StudentService {

	public List<StudentDetails>getAllStudents(); 
}
