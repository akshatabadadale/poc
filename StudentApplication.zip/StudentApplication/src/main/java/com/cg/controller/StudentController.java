package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cg.service.StudentService;

@Controller
@RequestMapping("/students")
public class StudentController {
	
	@Autowired
	StudentService studentService;
	
	
	
	@RequestMapping(value ="/getAllStudents",method = RequestMethod.GET)
	public String getAllStudents(Model model)
	{
		model.addAttribute("students",studentService.getAllStudents());
		
		return "studentListDisplay";
		
	}
}
